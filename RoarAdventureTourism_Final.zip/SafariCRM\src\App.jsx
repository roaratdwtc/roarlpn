import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  CalendarRange, 
  Users, 
  Car, 
  Receipt, 
  Handshake, 
  Compass,
  Menu,
  X,
  Database,
  Key,
  ShieldCheck,
  Settings,
  RefreshCw,
  Sparkles
} from 'lucide-react';
import DashboardView from './components/DashboardView';
import BookingsView from './components/BookingsView';
import CustomersView from './components/CustomersView';
import DriversView from './components/DriversView';
import PackagesView from './components/PackagesView';
import PartnersView from './components/PartnersView';
import CarFinanceView from './components/CarFinanceView';
import CustomerBookingView from './components/CustomerBookingView';
import LoginView from './components/LoginView';
import AdminAssistantView from './components/AdminAssistantView';
import { initialBookings, initialDrivers, initialExpenses, initialPartners, initialCars, initialPackages, initialCoupons } from './mockData';
// Safe localStorage and sessionStorage wrappers to prevent SecurityError when blocked
const safeStorage = {
  isSupported() {
    try {
      const testKey = '__storage_test__';
      window.localStorage.setItem(testKey, testKey);
      window.localStorage.removeItem(testKey);
      return true;
    } catch (e) {
      return false;
    }
  },
  memoryStore: {},
  getItem(key) {
    if (this.isSupported()) {
      try {
        return window.localStorage.getItem(key);
      } catch (e) {}
    }
    return this.memoryStore[key] !== undefined ? this.memoryStore[key] : null;
  },
  setItem(key, value) {
    if (this.isSupported()) {
      try {
        window.localStorage.setItem(key, value);
        return;
      } catch (e) {}
    }
    this.memoryStore[key] = String(value);
  },
  removeItem(key) {
    if (this.isSupported()) {
      try {
        window.localStorage.removeItem(key);
        return;
      } catch (e) {}
    }
    delete this.memoryStore[key];
  },
  clear() {
    if (this.isSupported()) {
      try {
        window.localStorage.clear();
        return;
      } catch (e) {}
    }
    this.memoryStore = {};
  }
};

const safeSessionStorage = {
  isSupported() {
    try {
      const testKey = '__session_test__';
      window.sessionStorage.setItem(testKey, testKey);
      window.sessionStorage.removeItem(testKey);
      return true;
    } catch (e) {
      return false;
    }
  },
  memoryStore: {},
  getItem(key) {
    if (this.isSupported()) {
      try {
        return window.sessionStorage.getItem(key);
      } catch (e) {}
    }
    return this.memoryStore[key] !== undefined ? this.memoryStore[key] : null;
  },
  setItem(key, value) {
    if (this.isSupported()) {
      try {
        window.sessionStorage.setItem(key, value);
        return;
      } catch (e) {}
    }
    this.memoryStore[key] = String(value);
  },
  removeItem(key) {
    if (this.isSupported()) {
      try {
        window.sessionStorage.removeItem(key);
        return;
      } catch (e) {}
    }
    delete this.memoryStore[key];
  },
  clear() {
    if (this.isSupported()) {
      try {
        window.sessionStorage.clear();
        return;
      } catch (e) {}
    }
    this.memoryStore = {};
  }
};

const localStorage = safeStorage;
const sessionStorage = safeSessionStorage;

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isProfilePopupOpen, setIsProfilePopupOpen] = useState(false);

  // Database version reset check
  const DB_VERSION = 'v31.0';
  useEffect(() => {
    localStorage.setItem('safari_db_version', DB_VERSION);
  }, []);

  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return sessionStorage.getItem('safari_admin_authenticated') === 'true';
  });
  const [isCustomerView, setIsCustomerView] = useState(() => {
    return window.location.hash === '#/book' || window.location.search.includes('view=customer');
  });

  // Track Hash Route Changes for Shared Link Navigation
  useEffect(() => {
    const handleHashChange = () => {
      setIsCustomerView(window.location.hash === '#/book' || window.location.search.includes('view=customer'));
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Helper for safe localStorage parsing
  const getLocalStorageItemSafe = (key, fallback) => {
    try {
      const saved = localStorage.getItem(key);
      if (!saved || saved === 'undefined') return fallback;
      return JSON.parse(saved);
    } catch (e) {
      console.error(`Failed to parse localStorage key ${key}:`, e);
      return fallback;
    }
  };

  // central state with dynamic loading & automatic cache invalidation
  const [bookings, setBookings] = useState(() => {
    const isNewVersion = localStorage.getItem('safari_db_version') !== DB_VERSION;
    if (isNewVersion) {
      localStorage.setItem('safari_bookings', JSON.stringify(initialBookings));
      return initialBookings;
    }
    return getLocalStorageItemSafe('safari_bookings', initialBookings);
  });

  const [drivers, setDrivers] = useState(() => {
    const isNewVersion = localStorage.getItem('safari_db_version') !== DB_VERSION;
    if (isNewVersion) {
      localStorage.setItem('safari_drivers', JSON.stringify(initialDrivers));
      return initialDrivers;
    }
    return getLocalStorageItemSafe('safari_drivers', initialDrivers);
  });

  const [expenses, setExpenses] = useState(() => {
    const isNewVersion = localStorage.getItem('safari_db_version') !== DB_VERSION;
    if (isNewVersion) {
      localStorage.setItem('safari_expenses', JSON.stringify(initialExpenses));
      return initialExpenses;
    }
    return getLocalStorageItemSafe('safari_expenses', initialExpenses);
  });

  const [partners, setPartners] = useState(() => {
    const isNewVersion = localStorage.getItem('safari_db_version') !== DB_VERSION;
    if (isNewVersion) {
      localStorage.setItem('safari_partners', JSON.stringify(initialPartners));
      return initialPartners;
    }
    return getLocalStorageItemSafe('safari_partners', initialPartners);
  });

  const [cars, setCars] = useState(() => {
    const isNewVersion = localStorage.getItem('safari_db_version') !== DB_VERSION;
    if (isNewVersion) {
      localStorage.setItem('safari_cars', JSON.stringify(initialCars));
      return initialCars;
    }
    return getLocalStorageItemSafe('safari_cars', initialCars);
  });

  const [packages, setPackages] = useState(() => {
    const isNewVersion = localStorage.getItem('safari_db_version') !== DB_VERSION;
    if (isNewVersion) {
      localStorage.setItem('safari_packages', JSON.stringify(initialPackages));
      return initialPackages;
    }
    return getLocalStorageItemSafe('safari_packages', initialPackages);
  });

  const [coupons, setCoupons] = useState(() => {
    const isNewVersion = localStorage.getItem('safari_db_version') !== DB_VERSION;
    if (isNewVersion) {
      localStorage.setItem('safari_coupons', JSON.stringify(initialCoupons));
      return initialCoupons;
    }
    return getLocalStorageItemSafe('safari_coupons', initialCoupons);
  });



  const [customers, setCustomers] = useState(() => {
    return getLocalStorageItemSafe('safari_customers', []);
  });

  const [settings, setSettings] = useState(() => {
    return getLocalStorageItemSafe('safari_settings', []);
  });

  // 1. Initial MySQL load effect
  const [dbStatus, setDbStatus] = useState(''); // 'loading', 'success', 'error', 'offline'
  useEffect(() => {
    const loadDatabase = async () => {
      setDbStatus('loading');
      try {
        const res = await fetch('api.php?action=load');
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const result = await res.json();
        if (result.status === 'success' && result.data) {
          const { bookings: bList, drivers: dList, expenses: eList, partners: pList, cars: cList, packages: pkgList, coupons: cpnList, customers: custList, settings: settingsList } = result.data;
          const seedPayload = {};
          
          let processedBList = bList || [];
          if (bList && bList.length > 0) {
            const todayStr = new Date(new Date().getTime() - new Date().getTimezoneOffset() * 60000).toISOString().split('T')[0];
            let listUpdated = false;
            processedBList = bList.map(b => {
               if (b.date < todayStr) {
                 // Past booking: completed or cancelled
                 if (b.status !== 'completed' && b.status !== 'cancelled') {
                   listUpdated = true;
                   const updatedB = { ...b, status: 'completed' };
                   fetch('api.php?action=save&table=bookings', {
                     method: 'POST',
                     headers: { 'Content-Type': 'application/json' },
                     body: JSON.stringify(updatedB)
                   });
                   return updatedB;
                 }
               } else {
                 // Upcoming or today booking: default to confirmed if not set
                 if (!b.status) {
                   listUpdated = true;
                   const updatedB = { ...b, status: 'confirmed' };
                   fetch('api.php?action=save&table=bookings', {
                     method: 'POST',
                     headers: { 'Content-Type': 'application/json' },
                     body: JSON.stringify(updatedB)
                   });
                    return updatedB;
                  }
                }
                return b;
             });
            
            if (listUpdated) {
              setBookings(processedBList);
              localStorage.setItem('safari_bookings', JSON.stringify(processedBList));
            } else {
              setBookings(bList);
            }
          } else {
            // Seeding falls back to default initialBookings from mockData!
            setBookings(initialBookings);
            localStorage.setItem('safari_bookings', JSON.stringify(initialBookings));
            seedPayload.bookings = initialBookings;
          }
          
          if (dList && dList.length > 0) {
            setDrivers(dList);
          } else {
            setDrivers(initialDrivers);
            localStorage.setItem('safari_drivers', JSON.stringify(initialDrivers));
            seedPayload.drivers = initialDrivers;
          }
          
          if (eList && eList.length > 0) {
            setExpenses(eList);
          } else {
            setExpenses(initialExpenses);
            localStorage.setItem('safari_expenses', JSON.stringify(initialExpenses));
            seedPayload.expenses = initialExpenses;
          }
          
          if (pList && pList.length > 0) {
            setPartners(pList);
          } else {
            setPartners(initialPartners);
            localStorage.setItem('safari_partners', JSON.stringify(initialPartners));
            seedPayload.partners = initialPartners;
          }
          
          if (cList && cList.length > 0) {
            setCars(cList);
          } else {
            setCars(initialCars);
            localStorage.setItem('safari_cars', JSON.stringify(initialCars));
            seedPayload.cars = initialCars;
          }

          if (pkgList && pkgList.length > 0) {
            setPackages(pkgList);
          } else {
            setPackages(initialPackages);
            localStorage.setItem('safari_packages', JSON.stringify(initialPackages));
            seedPayload.packages = initialPackages;
          }

          if (cpnList && cpnList.length > 0) {
            setCoupons(cpnList);
          } else {
            setCoupons(initialCoupons);
            localStorage.setItem('safari_coupons', JSON.stringify(initialCoupons));
            seedPayload.coupons = initialCoupons;
          }

          if (custList && custList.length > 0) {
            setCustomers(custList);
          } else {
            setCustomers([]);
            localStorage.setItem('safari_customers', JSON.stringify([]));
          }

          if (settingsList && settingsList.length > 0) {
            setSettings(settingsList);
            localStorage.setItem('safari_settings', JSON.stringify(settingsList));
          } else {
            const defaultSettings = [{ setting_key: 'show_coupons', setting_value: '1' }];
            setSettings(defaultSettings);
            localStorage.setItem('safari_settings', JSON.stringify(defaultSettings));
          }
          
          if (Object.keys(seedPayload).length > 0) {
            console.log("Seeding empty database tables:", Object.keys(seedPayload));
            fetch('api.php?action=reseed', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(seedPayload)
            }).catch(err => console.error("Auto-seeding empty tables failed:", err));
          }
          setDbStatus('success');
        } else {
          console.warn("MySQL returned error, using local storage cache:", result.message);
          setDbStatus('offline');
        }
      } catch (e) {
        console.error("MySQL loading failed, using local storage cache:", e);
        setDbStatus('offline');
      }
    };
    loadDatabase();
  }, []);

  const saveSetting = async (key, value) => {
    try {
      const res = await fetch('api.php?action=save_setting', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key, value })
      });
      const r = await res.json();
      if (r.status === 'success') {
        const updated = settings.some(s => s.setting_key === key)
          ? settings.map(s => s.setting_key === key ? { ...s, setting_value: value } : s)
          : [...settings, { setting_key: key, setting_value: value }];
        setSettings(updated);
        localStorage.setItem('safari_settings', JSON.stringify(updated));
      }
    } catch (err) {
      console.error("Failed to save setting:", err);
    }
  };

  // 2. Always keep localStorage cache updated
  useEffect(() => {
    localStorage.setItem('safari_bookings', JSON.stringify(bookings));
  }, [bookings]);

  useEffect(() => {
    localStorage.setItem('safari_drivers', JSON.stringify(drivers));
  }, [drivers]);

  useEffect(() => {
    localStorage.setItem('safari_expenses', JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem('safari_partners', JSON.stringify(partners));
  }, [partners]);

  useEffect(() => {
    localStorage.setItem('safari_cars', JSON.stringify(cars));
  }, [cars]);

  useEffect(() => {
    localStorage.setItem('safari_packages', JSON.stringify(packages));
  }, [packages]);

  useEffect(() => {
    localStorage.setItem('safari_coupons', JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    localStorage.setItem('safari_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('safari_customers', JSON.stringify(customers));
  }, [customers]);

  // 3. MySQL REST Sync Factory
  const createFirestoreSync = (colName, currentState, localSetter) => {
    return async (value) => {
      let nextList;
      if (typeof value === 'function') {
        nextList = value(currentState);
      } else {
        nextList = value;
      }
      
      // Update local state synchronously for instant UI
      localSetter(nextList);

      try {
        // Find added or modified items
        for (const nextItem of nextList) {
          const currentItem = currentState.find(c => c.id === nextItem.id);
          if (!currentItem || JSON.stringify(currentItem) !== JSON.stringify(nextItem)) {
            const res = await fetch(`api.php?action=save&table=${colName}`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(nextItem)
            });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const result = await res.json();
            if (result.status !== 'success') {
              throw new Error(result.message || 'Database rejected payload.');
            }
          }
        }

        // Find deleted items
        for (const currentItem of currentState) {
          if (!nextList.some(n => n.id === currentItem.id)) {
            const res = await fetch(`api.php?action=delete&table=${colName}`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: currentItem.id })
            });
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const result = await res.json();
            if (result.status !== 'success') {
              throw new Error(result.message || 'Database rejected deletion.');
            }
          }
        }
      } catch (e) {
        console.error(`Error syncing ${colName} update to MySQL:`, e);
        alert(`Database Sync Error: Failed to save changes in '${colName}' table on your hosting server.\n\nDetails: ${e.message || e}\n\nNote: Changes are saved in your browser locally, but please verify your database connection.`);
      }
    };
  };

  const [syncStatus, setSyncStatus] = useState(''); // 'saving', 'saved', 'error', ''

  const handleSyncDatabase = async () => {
    setSyncStatus('saving');
    try {
      const payload = { bookings, drivers, expenses, partners, cars };
      const res = await fetch('api.php?action=reseed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const result = await res.json();
      if (result.status === 'success') {
        setSyncStatus('saved');
        setTimeout(() => setSyncStatus(''), 2500);
      } else {
        throw new Error(result.message);
      }
    } catch (e) {
      console.error("Manual database sync failed:", e);
      setSyncStatus('error');
      setTimeout(() => setSyncStatus(''), 4000);
      alert(`Failed to save database. Error: ${e.message || e}`);
    }
  };

  const handleReseedDatabase = async () => {
    const confirmReseed = window.confirm(
      "CAUTION: This will overwrite ALL data in the database with the local template files (including the latest bookings imported from the PDF). " +
      "Any modifications done directly on the web app which were not committed will be lost. Do you want to proceed?"
    );
    if (!confirmReseed) return;
    
    setSyncStatus('saving');
    try {
      const payload = {
        bookings: initialBookings,
        drivers: initialDrivers,
        expenses: initialExpenses,
        partners: initialPartners,
        cars: initialCars
      };
      
      const res = await fetch('api.php?action=reseed', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      
      const result = await res.json();
      if (result.status !== 'success') {
        throw new Error(result.message);
      }

      // Clear local storage cache of current variables
      localStorage.removeItem('safari_bookings');
      localStorage.removeItem('safari_cars');
      localStorage.removeItem('safari_drivers');
      localStorage.removeItem('safari_partners');
      localStorage.removeItem('safari_expenses');

      alert("Database reset and reseeded successfully from local template files! The page will now reload.");
      window.location.reload();
    } catch (e) {
      console.error("Reseed failed:", e);
      alert(`Reseed failed. Error: ${e.message || e}`);
    }
  };

  const handleForceSyncBooking = async (booking) => {
    try {
      const res = await fetch(`api.php?action=save&table=bookings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(booking)
      });
      const result = await res.json();
      if (result.status === 'success') {
        alert(`Booking ${booking.customerName} (Ref: ${booking.id}) synced to database successfully!`);
      } else {
        throw new Error(result.message);
      }
    } catch (e) {
      console.error("Force sync booking failed:", e);
      alert(`Failed to sync booking to database. Error: ${e.message || e}`);
    }
  };

  const setBookingsCustom = createFirestoreSync('bookings', bookings, setBookings);
  const setDriversCustom = createFirestoreSync('drivers', drivers, setDrivers);
  const setExpensesCustom = createFirestoreSync('expenses', expenses, setExpenses);
  const setPartnersCustom = createFirestoreSync('partners', partners, setPartners);
  const setCarsCustom = createFirestoreSync('cars', cars, setCars);
  const setPackagesCustom = createFirestoreSync('packages', packages, setPackages);
  const setCouponsCustom = createFirestoreSync('coupons', coupons, setCoupons);
  const setCustomersCustom = createFirestoreSync('customers', customers, setCustomers);

  // Tab Header Mapping
  const tabTitles = {
    dashboard: 'BI Analytics Dashboard',
    bookings: 'Safari Bookings Manager',
    customers: 'Customer Directory',
    drivers: 'Drivers Registry',
    expenses: 'Driver Trip Expenses & Addons',
    packages: 'Safari Packages & Coupons Manager',
    partners: 'Partners Setup & Statement Generator',
    carsFreelancers: 'Cars & Freelancer Profiles Manager',
    carFinance: 'Car Finance Ledger',
    whatsappAgent: 'WhatsApp Agent & CRM Sandbox',
    adminAssistant: 'Admin AI Assistant Chat'
  };

  // Update browser window tab title to match current panel
  useEffect(() => {
    if (isCustomerView) {
      document.title = "Roar Adventure Tourism - Special Safari Packages Booking";
    } else {
      document.title = `Roar Safari ERP - ${tabTitles[activeTab] || 'Dashboard'}`;
    }
  }, [activeTab, isCustomerView]);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    setIsMobileSidebarOpen(false);
  };

  if (isCustomerView) {
    return (
      <CustomerBookingView 
        bookings={bookings} 
        setBookings={setBookingsCustom} 
        partners={partners} 
        packages={packages}
        coupons={coupons}
        customers={customers}
        setCustomers={setCustomersCustom}
        settings={settings}
      />
    );
  }

  if (!isAuthenticated) {
    return (
      <LoginView 
        onLoginSuccess={() => {
          sessionStorage.setItem('safari_admin_authenticated', 'true');
          setIsAuthenticated(true);
        }}
      />
    );
  }

  return (
    <div className="app-container">
      {/* Sidebar mobile overlay background click */}
      {isMobileSidebarOpen && (
        <div className="sidebar-overlay" onClick={() => setIsMobileSidebarOpen(false)}></div>
      )}

      {/* Sidebar Navigation */}
      <aside className={`sidebar ${isMobileSidebarOpen ? 'mobile-open' : ''}`}>
        <div className="logo-section" style={{ position: 'relative', background: '#ffffff', borderRadius: '10px', margin: '14px', padding: '10px', boxShadow: '0 2px 8px rgba(0,0,0,0.04)', border: '1px solid rgba(0,0,0,0.05)' }}>
          <img src="/logo.jpg" alt="Roar Adventure Tourism Logo" style={{ width: '100%', maxHeight: '48px', objectFit: 'contain' }} />
          {isMobileSidebarOpen && (
            <button 
              onClick={() => setIsMobileSidebarOpen(false)} 
              style={{ 
                position: 'absolute', 
                top: '12px', 
                right: '12px', 
                background: 'rgba(255,255,255,0.8)', 
                border: '1px solid var(--border)', 
                color: 'var(--text-muted)', 
                cursor: 'pointer',
                borderRadius: '50%',
                width: '24px',
                height: '24px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center'
              }}
            >
              <X size={14} />
            </button>
          )}
        </div>

        <ul className="nav-links">
          <li>
            <div 
              onClick={() => handleTabChange('dashboard')} 
              className={`nav-item ${activeTab === 'dashboard' ? 'active' : ''}`}
            >
              <LayoutDashboard /> Dashboard BI
            </div>
          </li>
          <li>
            <div 
              onClick={() => handleTabChange('bookings')} 
              className={`nav-item ${activeTab === 'bookings' ? 'active' : ''}`}
            >
              <CalendarRange /> Bookings
            </div>
          </li>
          <li>
            <div 
              onClick={() => handleTabChange('customers')} 
              className={`nav-item ${activeTab === 'customers' ? 'active' : ''}`}
            >
              <Users /> Customers
            </div>
          </li>
          <li>
            <div 
              onClick={() => handleTabChange('drivers')} 
              className={`nav-item ${activeTab === 'drivers' ? 'active' : ''}`}
            >
              <Car /> Drivers
            </div>
          </li>
          <li>
            <div 
              onClick={() => handleTabChange('packages')} 
              className={`nav-item ${activeTab === 'packages' ? 'active' : ''}`}
            >
              <Compass /> Packages & Coupons
            </div>
          </li>
          <li>
            <div 
              onClick={() => handleTabChange('partners')} 
              className={`nav-item ${activeTab === 'partners' ? 'active' : ''}`}
            >
              <Handshake /> Partners & Invoices
            </div>
          </li>
          <li>
            <div 
              onClick={() => handleTabChange('carsFreelancers')} 
              className={`nav-item ${activeTab === 'carsFreelancers' ? 'active' : ''}`}
            >
              <Car /> Cars / Freelancers
            </div>
          </li>
          <li>
            <div 
              onClick={() => handleTabChange('carFinance')} 
              className={`nav-item ${activeTab === 'carFinance' ? 'active' : ''}`}
            >
              <Receipt /> Car Finance Ledger
            </div>
          </li>
          <li>
            <div 
              onClick={() => handleTabChange('adminAssistant')} 
              className={`nav-item ${activeTab === 'adminAssistant' ? 'active' : ''}`}
            >
              <Sparkles /> AI Admin Assistant
            </div>
          </li>
        </ul>

        <div className="sidebar-footer" style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
          <button 
            onClick={() => {
              sessionStorage.removeItem('safari_admin_authenticated');
              setIsAuthenticated(false);
            }}
            className="btn btn-secondary" 
            style={{ width: '100%', fontSize: '11px', padding: '6px 12px', justifyContent: 'center' }}
          >
            Sign Out
          </button>
          <div style={{ textAlign: 'center' }}>
            <div>Dubai Desert Safari</div>
            <div style={{ fontSize: '10px', marginTop: '4px', color: 'var(--text-muted)' }}>v2.0 Premium ERP</div>
          </div>
        </div>
      </aside>

      {/* Main Panel View */}
      <main className="main-content">
        <header className="top-bar">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <button className="mobile-hamburger" onClick={() => setIsMobileSidebarOpen(true)}>
              <Menu size={24} />
            </button>
            <img 
              src="/logo.jpg" 
              alt="Roar Logo" 
              className="mobile-logo-topbar" 
            />
            <h2 className="topbar-title">{tabTitles[activeTab]}</h2>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>

            <div 
              onClick={() => setIsProfilePopupOpen(true)}
              style={{ 
                display: 'flex', 
                alignItems: 'center', 
                gap: '8px', 
                cursor: 'pointer', 
                background: 'rgba(140, 91, 48, 0.05)', 
                padding: '6px 12px', 
                borderRadius: '30px', 
                border: '1px solid rgba(140, 91, 48, 0.1)', 
                transition: 'all 0.2s',
                userSelect: 'none'
              }}
              onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(140, 91, 48, 0.08)'}
              onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(140, 91, 48, 0.05)'}
            >
              <img 
                src="/logo.jpg" 
                alt="Roar Icon" 
                style={{ width: '22px', height: '22px', borderRadius: '50%', objectFit: 'contain', background: '#fff', border: '1px solid rgba(0,0,0,0.05)' }} 
              />
              <span style={{ fontSize: '12.5px', fontWeight: '800', color: 'var(--text-dark)' }}>Admin</span>
            </div>
          </div>
        </header>

        <section className="view-container">
          {activeTab === 'dashboard' && (
            <DashboardView 
              bookings={bookings} 
              drivers={drivers} 
              expenses={expenses} 
              partners={partners}
              packages={packages}
              setActiveTab={handleTabChange}
            />
          )}

          {activeTab === 'bookings' && (
            <BookingsView 
              bookings={bookings} 
              setBookings={setBookingsCustom} 
              drivers={drivers} 
              partners={partners} 
              expenses={expenses}
              packages={packages}
              coupons={coupons}
              onForceSyncBooking={handleForceSyncBooking}
            />
          )}

          {activeTab === 'customers' && (
            <CustomersView 
              bookings={bookings} 
              drivers={drivers}
              packages={packages}
              registeredCustomers={customers}
            />
          )}

          {activeTab === 'drivers' && (
            <DriversView 
              drivers={drivers} 
              setDrivers={setDriversCustom} 
              bookings={bookings} 
              expenses={expenses} 
              packages={packages}
              setActiveTab={handleTabChange}
            />
          )}

          {activeTab === 'packages' && (
            <PackagesView 
              packages={packages} 
              setPackages={setPackagesCustom} 
              coupons={coupons} 
              setCoupons={setCouponsCustom} 
              settings={settings}
              onSaveSetting={saveSetting}
            />
          )}

          {activeTab === 'partners' && (
            <PartnersView 
              partners={partners} 
              setPartners={setPartnersCustom} 
              bookings={bookings} 
              packages={packages}
            />
          )}

          {activeTab === 'carsFreelancers' && (
            <CarFinanceView 
              cars={cars} 
              setCars={setCarsCustom} 
              drivers={drivers}
              viewMode="registry"
            />
          )}

          {activeTab === 'carFinance' && (
            <CarFinanceView 
              cars={cars} 
              setCars={setCarsCustom} 
              drivers={drivers}
              viewMode="ledger"
            />
          )}

          {activeTab === 'adminAssistant' && (
            <AdminAssistantView />
          )}
        </section>
      </main>
      {/* Admin Profile Details Modal */}
      {isProfilePopupOpen && (
        <div className="modal-overlay" style={{ zIndex: 2000 }}>
          <div className="modal-content" style={{ maxWidth: '400px', textAlign: 'center', padding: '32px 24px' }}>
            <div className="modal-header" style={{ borderBottom: 'none', marginBottom: '8px', padding: 0 }}>
              <h3 style={{ fontSize: '18px', fontWeight: '800', width: '100%', textAlign: 'center' }}>Admin Profile</h3>
              <button onClick={() => setIsProfilePopupOpen(false)} className="modal-close" style={{ position: 'absolute', right: '16px', top: '16px' }}>&times;</button>
            </div>
            
             <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px', marginTop: '12px' }}>
              <div style={{ background: '#fff', borderRadius: '12px', padding: '12px 20px', boxShadow: '0 4px 12px rgba(0,0,0,0.03)', border: '1px solid rgba(0,0,0,0.04)' }}>
                <img src="/logo.jpg" alt="Roar Adventure Tourism" style={{ maxHeight: '42px', objectFit: 'contain' }} />
              </div>
              
              <div style={{ width: '100%', display: 'flex', flexDirection: 'column', gap: '12px', background: 'rgba(0,0,0,0.015)', border: '1px solid var(--border)', borderRadius: '12px', padding: '16px', fontSize: '13px', textAlign: 'left', marginTop: '10px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)', fontWeight: '600' }}>Name:</span>
                  <span style={{ fontWeight: '700', color: 'var(--text-dark)' }}>Operations Manager</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)', fontWeight: '600' }}>Company:</span>
                  <span style={{ fontWeight: '700' }}>Roar Adventure Tourism</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)', fontWeight: '600' }}>Email:</span>
                  <span style={{ fontWeight: '600', color: 'var(--primary)' }}>info@roaradventuretourism.com</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ color: 'var(--text-muted)', fontWeight: '600' }}>Phone:</span>
                  <span style={{ fontWeight: '700' }}>+971 556054570</span>
                                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '1px solid var(--border-light)', paddingTop: '10px' }}>
                  <span style={{ color: 'var(--text-muted)', fontWeight: '600' }}>Database Status:</span>
                  <span style={{ fontWeight: '700', color: dbStatus === 'success' ? 'var(--success)' : '#ef4444', display: 'flex', alignItems: 'center', gap: '4px' }}>
                    {dbStatus === 'success' ? (
                      <>
                        <ShieldCheck size={14} /> MySQL Connected
                      </>
                    ) : (
                      <>
                        <Database size={14} /> Local Offline Mode
                      </>
                    )}
                  </span>
                </div>
              </div>



              <div style={{ display: 'flex', gap: '10px', width: '100%', marginTop: '4px' }}>
                <button 
                  onClick={() => setIsProfilePopupOpen(false)} 
                  className="btn btn-secondary"
                  style={{ flex: 1, justifyContent: 'center' }}
                >
                  Close
                </button>
                <button 
                  onClick={() => {
                    setIsProfilePopupOpen(false);
                    sessionStorage.removeItem('safari_admin_authenticated');
                    setIsAuthenticated(false);
                  }} 
                  className="btn btn-primary"
                  style={{ flex: 1, justifyContent: 'center', background: '#ef4444', borderColor: '#ef4444' }}
                >
                  Sign Out
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
