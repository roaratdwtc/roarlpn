import React, { useState } from "react";
import { CheckCircle, Check, Send, Sparkles } from "lucide-react";
import { safariPackages } from "../mockData";

// Addons definition
const ADDONS = [
  { key: "camelRide",          label: "Long Camel Ride",    price: 30, unit: "/person",               icon: "🐫", always: true  },
  { key: "falconPhoto",        label: "Falcon Photography", price: 20, unit: "/person",               icon: "🦅", always: true  },
  { key: "acSeating",          label: "AC Seating Upgrade", price: 25, unit: "/person",               icon: "❄️", always: false, vipOnly: true },
  { key: "sheesha",            label: "Sheesha on Table",   price: 50, unit: "/table (1 per 3 pax)",  icon: "💨", always: true  },
  { key: "professionalPhotos", label: "Professional Photos",price: 20, unit: "/photo (print+digital)",icon: "📸", always: true  },
];

// Lock same-day booking after 3pm UAE (UTC+4)
function getMinDate() {
  const now = new Date();
  const uaeOffset = 4 * 60;
  const uaeMs = now.getTime() + (uaeOffset - now.getTimezoneOffset()) * 60000;
  const uae = new Date(uaeMs);
  if (uae.getUTCHours() >= 15) {
    uae.setUTCDate(uae.getUTCDate() + 1);
  }
  return uae.toISOString().split("T")[0];
}

const colors = {
  copper: "#c9762a",
  gold: "#c5a059",
  creamBg: "#fffdfb",
  sandBg: "#faf6f0",
  white: "#ffffff",
  textDark: "#543d2b",
  textMuted: "#9e8a78",
  border: "#efe9df",
  successText: "#15803d",
  successBg: "#f0fdf4",
};

const inpStyle = {
  width: "100%",
  padding: "12px 14px",
  borderRadius: "10px",
  border: `1.5px solid ${colors.border}`,
  background: colors.white,
  fontSize: "14px",
  color: colors.textDark,
  outline: "none",
  boxSizing: "border-box",
  fontFamily: "inherit",
  transition: "all 0.2s",
};

export default function CustomerBookingView({ bookings, setBookings, partners = [], packages = [], coupons = [], customers = [], setCustomers, settings = [] }) {
  const activePackages = packages.length > 0 ? packages : safariPackages;
  const showCouponsSetting = settings.find(s => s.setting_key === 'show_coupons')?.setting_value !== '0';

  const categoryOrder = {
    "Self Drive Safari": 1,
    "Evening Desert Safari": 2,
    "Morning Desert Safari": 3,
    "Dune Buggy Ride": 4,
    "City Tours": 5
  };

  // Only show categories that contain "Safari"
  const categoriesList = [...new Set(activePackages.map(p => p.category))]
    .filter(cat => (cat || "").toLowerCase().includes("safari"))
    .sort((a, b) => {
      const orderA = categoryOrder[a] || 999;
      const orderB = categoryOrder[b] || 999;
      return orderA - orderB;
    });

  const initialCategory = categoriesList[0] || "Evening Desert Safari";
  const initialSubPackages = activePackages
    .filter(p => p.category === initialCategory)
    .sort((a, b) => (parseFloat(a.rate) || 0) - (parseFloat(b.rate) || 0));
  const initialSubPkg = initialSubPackages[0] || null;

  const [formData, setFormData] = useState({
    customerName: "",
    email: "",
    whatsapp: "",
    pickupLocation: "",
    roomNo: "",
    date: "",
    pax: 2, // Default to 2 guests, can be decremented to 1
    categoryKey: initialCategory,
    subPackageId: initialSubPkg ? initialSubPkg.id : "",
    message: "",
  });

  const [addonQty, setAddonQty] = useState({});
  const handlePaxChange = (newPax) => {
    setFormData(prev => ({ ...prev, pax: newPax }));
    setAddonQty(prev => {
      const updated = { ...prev };
      displayAddons.forEach(a => {
        if (prev[a.key] > 0 && a.unit && a.unit.includes('/person')) {
          updated[a.key] = newPax;
        }
      });
      return updated;
    });
  };
  const [couponCode, setCouponCode] = useState("");
  const [tempCouponCode, setTempCouponCode] = useState("");
  const [isCouponUnlocked, setIsCouponUnlocked] = useState(false);
  const [isUnlockModalOpen, setIsUnlockModalOpen] = useState(false);
  const [leadEmail, setLeadEmail] = useState("");

  const getCleanPackageName = (name) => {
    if (!name) return "";
    return name.replace(/\s?\d+\s?AED/gi, "").trim();
  };

  const [submitted, setSubmitted] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  // Sync sub-package list and active sub-package dynamically, sorted by price ascending
  const subPackagesList = activePackages
    .filter(p => p.category === formData.categoryKey)
    .sort((a, b) => (parseFloat(a.rate) || 0) - (parseFloat(b.rate) || 0));
  const selectedPkg = activePackages.find(p => p.id === formData.subPackageId) || subPackagesList[0];

  // AC Seating availability condition: Only available in Evening Desert Safari and Self Drive Safari
  const showAcSeating = formData.categoryKey === "Evening Desert Safari" || formData.categoryKey === "Self Drive Safari";

  const isVip = selectedPkg && (
    selectedPkg.name.toLowerCase().includes("vip") ||
    selectedPkg.name.toLowerCase().includes("private") ||
    selectedPkg.name.toLowerCase().includes("premium")
  );

  const pax = Math.max(1, parseInt(formData.pax) || 1); // Enforce minimum of 1 guest

  // Resolve dynamic addons list
  const displayAddons = (selectedPkg?.addons && selectedPkg.addons.length > 0)
    ? selectedPkg.addons.map(a => ({
        key: a.name,
        label: a.name,
        price: parseFloat(a.price) || 0,
        unit: "/person",
        icon: "✨",
        always: true
      }))
    : ADDONS.filter(a => {
        if (a.key === "acSeating" && !showAcSeating) return false;
        return a.always || isVip;
      });

  const getCouponValidationStatus = (codeVal, pkgId) => {
    if (!codeVal) return { status: 'none', message: '' };
    if (coupons.length === 0) return { status: 'invalid', message: '✗ Invalid coupon code' };

    const cleanCode = codeVal.trim().toLowerCase();
    const todayStr = new Date(new Date().getTime() - new Date().getTimezoneOffset() * 60000).toISOString().split('T')[0];

    const matchingCodes = coupons.filter(c => c.code.trim().toLowerCase() === cleanCode);
    if (matchingCodes.length === 0) {
      return { status: 'invalid', message: '✗ Invalid coupon code' };
    }

    const activeAndNotExpired = matchingCodes.filter(c => {
      if (parseInt(c.isActive) === 0) return false;
      if (c.endDate && todayStr > c.endDate) return false;
      return true;
    });

    if (activeAndNotExpired.length === 0) {
      const isExpired = matchingCodes.some(c => c.endDate && todayStr > c.endDate);
      if (isExpired) {
        return { status: 'expired', message: '✗ Coupon code expired' };
      }
      return { status: 'inactive', message: '✗ Coupon code is currently inactive' };
    }

    const selectedPkgObj = activePackages.find(p => p.id === pkgId);
    const isEveningSafari = selectedPkgObj && selectedPkgObj.category === 'Evening Desert Safari';
    const isMorningPrivate = pkgId === 'morning_private';

    const matchesPkg = activeAndNotExpired.find(c => {
      if (c.packageId === pkgId) return true;
      if (c.packageId === 'all_safari' && (isEveningSafari || isMorningPrivate)) return true;
      return false;
    });

    if (!matchesPkg) {
      return { status: 'wrong_package', message: '✗ Coupon code not valid for this package' };
    }

    if (matchesPkg.packageId === 'all_safari' && selectedPkgObj) {
      const offpeakRate = parseFloat(selectedPkgObj.offpeakRate) || parseFloat(selectedPkgObj.rate) || 0;
      return {
        status: 'valid',
        message: `✓ Coupon Applied: AED ${offpeakRate} package price override`,
        coupon: { ...matchesPkg, customPrice: offpeakRate }
      };
    }

    return { status: 'valid', message: `✓ Coupon Applied: AED ${matchesPkg.customPrice} package price override`, coupon: matchesPkg };
  };

  const activeCoupons = coupons.filter(c => parseInt(c.isActive) !== 0);
  const promoCoupon = activeCoupons[0];

  const handleUnlockCoupon = async (e) => {
    e.preventDefault();
    if (!formData.customerName.trim() || !formData.whatsapp.trim()) {
      alert("Please fill in your Name and WhatsApp number under 'Tour Details' first before unlocking the coupon.");
      return;
    }

    if (!formData.whatsapp.trim().startsWith("+")) {
      alert("WhatsApp number must include a country code starting with '+' (e.g. +971569468126).");
      return;
    }

    if (!leadEmail.trim()) {
      alert("Email address is mandatory.");
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(leadEmail.trim())) {
      alert("Please enter a valid email address.");
      return;
    }

    const customerLead = {
      id: `cust-${Date.now()}`,
      name: formData.customerName.trim(),
      whatsapp: formData.whatsapp.trim(),
      email: leadEmail.trim()
    };

    try {
      const res = await fetch("api.php?action=save&table=customers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(customerLead)
      });
      const r = await res.json();
      if (r.status !== "success") {
        throw new Error(r.message);
      }

      if (setCustomers && typeof setCustomers === 'function') {
        setCustomers(prev => [customerLead, ...prev]);
      }

      setIsCouponUnlocked(true);
      setCouponCode(promoCoupon.code);
      setTempCouponCode(promoCoupon.code);

      setFormData(prev => ({
        ...prev,
        email: leadEmail.trim()
      }));

      alert(`🎉 Coupon "${promoCoupon.code}" unlocked and applied successfully!`);
      setIsUnlockModalOpen(false);
    } catch (err) {
      alert("Failed to unlock coupon: " + (err.message || err));
    }
  };

  const cpnStatus = showCouponsSetting ? getCouponValidationStatus(couponCode, selectedPkg?.id) : { status: 'none', message: '' };
  const activeCpn = cpnStatus.status === 'valid' ? cpnStatus.coupon : null;

  // Price calculations
  let basePrice = 0;
  let carsNeeded = 1;
  if (selectedPkg) {
    const isEveningSafari = selectedPkg.category === 'Evening Desert Safari';
    const isMorningPrivate = selectedPkg.id === 'morning_private';

    let defaultRate = (isEveningSafari || isMorningPrivate)
      ? (parseFloat(selectedPkg.peakRate) || parseFloat(selectedPkg.rate) || 0)
      : (parseFloat(selectedPkg.rate) || 0);

    let rate = defaultRate;
    if (activeCpn) {
      rate = parseFloat(activeCpn.customPrice) || 0;
    }

    if (selectedPkg.type === "flat") {
      carsNeeded = Math.ceil(pax / 6) || 1;
      basePrice = rate * carsNeeded;
    } else {
      basePrice = rate * pax;
    }
  }

  const addonsTotal = displayAddons.reduce((s, a) => {
    return s + (addonQty[a.key] || 0) * a.price;
  }, 0);

  const totalPrice = basePrice + addonsTotal;

  const handleCategoryChange = e => {
    const catVal = e.target.value;
    const list = activePackages
      .filter(p => p.category === catVal)
      .sort((a, b) => (parseFloat(a.rate) || 0) - (parseFloat(b.rate) || 0));
    const defaultSubId = list[0] ? list[0].id : "";
    setFormData(prev => ({
      ...prev,
      categoryKey: catVal,
      subPackageId: defaultSubId
    }));
    setAddonQty({});
  };

  const handleSave = async e => {
    e.preventDefault();
    if (!formData.customerName || !formData.date || !formData.whatsapp || !formData.pickupLocation) {
      alert("Please fill in Name, WhatsApp, Date, and Pickup Location.");
      return;
    }
    const lines = displayAddons.filter(a => {
      return (addonQty[a.key] || 0) > 0;
    }).map(a => `${a.label} x${addonQty[a.key]} (+AED ${addonQty[a.key] * a.price})`);

    setSubmitting(true);
    const ref = `book-${Date.now()}`;
    const booking = {
      id: ref,
      customerName: formData.customerName,
      whatsapp: formData.whatsapp,
      email: formData.email,
      date: formData.date,
      packageName: selectedPkg ? selectedPkg.name : "",
      pickupLocation: formData.pickupLocation,
      roomNo: formData.roomNo,
      pickupTime: "3:30 PM to 4:00 PM",
      pax: pax,
      price: totalPrice,
      addonName: lines.join(", "),
      addonPrice: addonsTotal,
      partnerId: "website",
      status: "pending",
      driverId: "",
      couponCode: activeCpn ? activeCpn.code : "",
      pricingType: "offpeak"
    };
    try {
      const res = await fetch("api.php?action=save&table=bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(booking)
      });
      const r = await res.json();
      if (r.status === "success") {
        setBookings([booking, ...bookings]);
        setSubmitted(booking);
      } else {
        throw new Error(r.message);
      }
    } catch (err) {
      alert("Booking failed: " + (err.message || err));
    } finally {
      setSubmitting(false);
    }
  };

  const waLink = b => {
    if (!b) return "";
    const ref = b.id.replace("book-", "").toUpperCase() + "ASD";
    const t = `Hi Roar Adventure Tourism, confirming Ref# ${ref}:\n1. Name: ${b.customerName}\n2. WhatsApp: ${b.whatsapp}\n3. Guests: ${b.pax} pax\n4. Package: ${b.packageName}\n5. Date: ${(b.date||"").split("-").reverse().join("/")}\n6. Pickup: ${b.pickupLocation}${b.roomNo ? ` Rm ${b.roomNo}` : ""}${b.addonName ? `\n7. Addons: ${b.addonName}` : ""}\n${b.addonName ? "8" : "7"}. Total: AED ${b.price} (Pay on Arrival)`;
    return `https://wa.me/971556054570?text=${encodeURIComponent(t)}`;
  };

  /* ── Success Screen ──────────────────────────────────────────────────── */
  if (submitted) {
    const refCode = submitted.id.replace("book-", "").toUpperCase() + "ASD";
    return (
      <div style={{ minHeight: "100vh", background: colors.sandBg, display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
        <div className="glass-card" style={{ maxWidth: "520px", width: "100%", padding: "40px 36px", textAlign: "center", background: colors.white, border: `1.5px solid ${colors.border}`, borderRadius: "16px", boxShadow: "0 10px 30px rgba(0,0,0,0.03)" }}>
          <div style={{ width: "72px", height: "72px", borderRadius: "50%", background: colors.successBg, color: colors.successText, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}>
            <CheckCircle size={44} style={{ color: colors.gold }} />
          </div>
          <h2 style={{ fontSize: "24px", fontWeight: "900", color: colors.textDark, marginBottom: "6px" }}>Booking Received! 🎉</h2>
          <p style={{ color: colors.textMuted, fontSize: "14px", marginBottom: "24px" }}>
            Reference: <strong style={{ color: colors.gold, fontSize: "16px" }}>{refCode}</strong><br />WhatsApp us to confirm your slot.
          </p>
          <div style={{ background: colors.sandBg, border: `1px solid ${colors.border}`, borderRadius: "12px", padding: "18px", textAlign: "left", fontSize: "13px", display: "flex", flexDirection: "column", gap: "9px", marginBottom: "22px" }}>
            {[["👤 Name", submitted.customerName], ["📱 WhatsApp", submitted.whatsapp], ["👥 Guests", `${submitted.pax} Pax`], ["📅 Date", (submitted.date||"").split("-").reverse().join("/")], ["📍 Pickup", `${submitted.pickupLocation}${submitted.roomNo ? ` Rm ${submitted.roomNo}` : ""}`], ...(submitted.addonName ? [["✨ Addons", submitted.addonName]] : []), ["💰 Pay on Arrival", `AED ${submitted.price}`]].map(([l, v]) => (
              <div key={l} style={{ display: "flex", justifyContent: "space-between", gap: "10px" }}>
                <span style={{ color: colors.textMuted, fontWeight: "700", minWidth: "130px" }}>{l}</span>
                <span style={{ fontWeight: "800", color: colors.textDark, textAlign: "right" }}>{v}</span>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            <a href={waLink(submitted)} target="_blank" rel="noopener noreferrer"
              style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", background: colors.gold, color: colors.white, padding: "14px", borderRadius: "12px", textDecoration: "none", fontWeight: "800", fontSize: "15px", boxShadow: `0 4px 12px rgba(197,160,89,0.3)` }}>
              <Send size={16} /> Confirm on WhatsApp
            </a>
            <button onClick={() => setSubmitted(null)} style={{ background: "transparent", border: `1.5px solid ${colors.border}`, borderRadius: "12px", padding: "12px", cursor: "pointer", fontWeight: "700", color: colors.textMuted, fontSize: "14px", fontFamily: "inherit" }}>
              ← Book Another Safari
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ minHeight: "100vh", background: colors.sandBg, paddingBottom: "80px" }}>
      {/* Outer wrapper */}
      <div style={{ maxWidth: "1200px", margin: "0 auto", padding: "20px 16px 40px", display: "flex", flexDirection: "column", gap: "20px" }}>
        
        {/* Header Section */}
        <div style={{ textAlign: "center", marginTop: "12px", marginBottom: "8px" }}>
          {/* Logo */}
          <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '16px' }}>
            <img src="logo.jpg" alt="Roar Adventure Tourism Logo" style={{ maxHeight: '80px', borderRadius: '10px', objectFit: 'contain' }} />
          </div>

          <div style={{ display: "inline-block", background: "rgba(197, 160, 89, 0.1)", color: colors.gold, fontSize: "11px", fontWeight: "800", padding: "4px 14px", borderRadius: "20px", marginBottom: "10px", letterSpacing: "1px", border: `1px solid rgba(197, 160, 89, 0.2)` }}>
            PREMIUM DUBAI DESERT SAFARI
          </div>
          <h1 style={{ fontSize: "clamp(24px, 4vw, 36px)", fontWeight: "900", color: colors.textDark, margin: "0 0 8px", lineHeight: 1.2 }}>
            Instant Safari Booking
          </h1>
          <p style={{ color: colors.textMuted, fontSize: "14px", maxWidth: "680px", margin: "0 auto", lineHeight: 1.5 }}>
            Book your slot in seconds. Lock your rates automatically, choose optional addons, and pay cash directly to the driver on pickup.
          </p>
        </div>

        {/* Trust Cards Grid */}
        <div className="stats-grid" style={{ margin: '8px 0' }}>
          {[
            { icon: "🏆", title: "5-Star Service", desc: "Top rated desert safari on Google Maps by thousands of tourists." },
            { icon: "🔒", title: "Book Now, Pay Later", desc: "No deposit or credit card required. Pay cash directly to driver on arrival." },
            { icon: "✅", title: "Free Cancellation", desc: "Plans changed? Flexibly cancel or reschedule up to 24 hours in advance." }
          ].map((card, idx) => (
            <div key={idx} style={{ background: colors.white, border: `1.5px solid ${colors.border}`, padding: '16px 20px', borderRadius: '12px', display: 'flex', gap: '12px', alignItems: 'center', boxShadow: '0 2px 8px rgba(0,0,0,0.01)' }}>
              <span style={{ fontSize: '26px' }}>{card.icon}</span>
              <div>
                <h4 style={{ margin: '0 0 2px', fontSize: '14px', fontWeight: '800', color: colors.textDark }}>{card.title}</h4>
                <p style={{ margin: 0, fontSize: '12px', color: colors.textMuted, lineHeight: 1.4 }}>{card.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Form & Sidebar Layout */}
        <div className="booking-layout-grid">
          
          {/* Main Booking Form */}
          <div style={{ background: colors.white, border: `1.5px solid ${colors.border}`, borderRadius: "16px", padding: "24px", display: "flex", flexDirection: "column", gap: "20px" }}>
            
            {/* Step 1: Package Selection */}
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "16px", borderBottom: `1.5px solid ${colors.border}`, paddingBottom: "8px" }}>
                <span style={{ fontSize: "16px" }}>🏜️</span>
                <h3 style={{ fontSize: "15px", fontWeight: "900", color: colors.textDark, margin: 0 }}>Step 1: Select Safari Adventure</h3>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "12px" }}>
                <div>
                  <label style={{ fontSize: "11px", fontWeight: "800", color: colors.textMuted, display: "block", marginBottom: "5px" }}>Safari Type</label>
                  <select style={inpStyle} value={formData.categoryKey} onChange={handleCategoryChange}>
                    {categoriesList.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: "11px", fontWeight: "800", color: colors.textMuted, display: "block", marginBottom: "5px" }}>Package Choice</label>
                  {subPackagesList.length > 0 ? (
                    <select style={inpStyle} value={formData.subPackageId} onChange={e => setFormData({ ...formData, subPackageId: e.target.value })}>
                      {subPackagesList.map(sp => (
                        <option key={sp.id} value={sp.id}>{getCleanPackageName(sp.name)}</option>
                      ))}
                    </select>
                  ) : (
                    <div style={{ ...inpStyle, background: colors.sandBg, color: colors.textMuted }}>No options available</div>
                  )}
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: "12px", alignItems: "end" }}>
                {/* Guests Counter Selector */}
                <div>
                  <label style={{ fontSize: "11px", fontWeight: "800", color: colors.textMuted, display: "block", marginBottom: "5px" }}>Number of Guests</label>
                  <input 
                     style={inpStyle} 
                     type="number" 
                     min="1" 
                     max="50" 
                     value={formData.pax} 
                     onChange={e => handlePaxChange(Math.max(1, parseInt(e.target.value) || 1))} 
                     required 
                   />
                </div>

                <div>
                  <label style={{ fontSize: "11px", fontWeight: "800", color: colors.textMuted, display: "block", marginBottom: "5px" }}>Tour Date</label>
                  <input style={inpStyle} type="date" min={getMinDate()} value={formData.date} onChange={e => setFormData({ ...formData, date: e.target.value })} required />
                </div>
              </div>

              {selectedPkg?.description && (
                <div style={{ background: colors.sandBg, borderLeft: `3px solid ${colors.gold}`, padding: "10px 12px", borderRadius: "4px", fontSize: "12px", color: colors.textDark, marginTop: "14px", lineHeight: 1.4 }}>
                  💡 <strong>Inclusions</strong>: {selectedPkg.description}
                </div>
              )}
            </div>

            {/* Step 2: Contact & Pickup Details */}
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "16px", borderBottom: `1.5px solid ${colors.border}`, paddingBottom: "8px", marginTop: "8px" }}>
                <span style={{ fontSize: "16px" }}>👤</span>
                <h3 style={{ fontSize: "15px", fontWeight: "900", color: colors.textDark, margin: 0 }}>Step 2: Pickup & Contact Details</h3>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "12px" }}>
                <div>
                  <label style={{ fontSize: "11px", fontWeight: "800", color: colors.textMuted, display: "block", marginBottom: "5px" }}>Full Name *</label>
                  <input style={inpStyle} type="text" placeholder="e.g. John Doe" value={formData.customerName} onChange={e => setFormData({ ...formData, customerName: e.target.value })} required />
                </div>
                <div>
                  <label style={{ fontSize: "11px", fontWeight: "800", color: colors.textMuted, display: "block", marginBottom: "5px" }}>WhatsApp Number * (Include Country Code)</label>
                  <input style={inpStyle} type="tel" placeholder="e.g. +971500000000" value={formData.whatsapp} onChange={e => setFormData({ ...formData, whatsapp: e.target.value })} required />
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "12px" }}>
                <div>
                  <label style={{ fontSize: "11px", fontWeight: "800", color: colors.textMuted, display: "block", marginBottom: "5px" }}>Pickup Location / Hotel Name *</label>
                  <input style={inpStyle} type="text" placeholder="e.g. Marina Heights Tower, lobby" value={formData.pickupLocation} onChange={e => setFormData({ ...formData, pickupLocation: e.target.value })} required />
                </div>
                <div>
                  <label style={{ fontSize: "11px", fontWeight: "800", color: colors.textMuted, display: "block", marginBottom: "5px" }}>Room Number (Optional)</label>
                  <input style={inpStyle} type="text" placeholder="e.g. Rm 1204" value={formData.roomNo} onChange={e => setFormData({ ...formData, roomNo: e.target.value })} />
                </div>
              </div>

              <div style={{ marginBottom: "12px" }}>
                <label style={{ fontSize: "11px", fontWeight: "800", color: colors.textMuted, display: "block", marginBottom: "5px" }}>Email Address (Optional)</label>
                <input style={inpStyle} type="email" placeholder="e.g. name@example.com" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} />
              </div>

              <div>
                <label style={{ fontSize: "11px", fontWeight: "800", color: colors.textMuted, display: "block", marginBottom: "5px" }}>Special Requirements / Message (Optional)</label>
                <input style={inpStyle} placeholder="e.g. baby seat, vegetarian meals, etc." value={formData.message} onChange={e => setFormData({ ...formData, message: e.target.value })} />
              </div>
            </div>

            {/* Step 3: Optional Add-ons */}
            <div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px", borderBottom: `1.5px solid ${colors.border}`, paddingBottom: "8px", marginTop: "8px" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                  <span style={{ fontSize: "16px" }}>✨</span>
                  <h3 style={{ fontSize: "15px", fontWeight: "900", color: colors.textDark, margin: 0 }}>Step 3: Optional Add-ons</h3>
                </div>
                {addonsTotal > 0 && (
                  <div style={{ background: colors.gold, color: colors.white, fontSize: "11px", fontWeight: "800", padding: "2px 10px", borderRadius: "20px" }}>
                    +AED {addonsTotal}
                  </div>
                )}
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px" }}>
                {displayAddons.map(addon => {
                  const isChecked = (addonQty[addon.key] || 0) > 0;
                  return (
                    <label 
                      key={addon.key} 
                      style={{ 
                        background: isChecked ? "rgba(197, 160, 89, 0.05)" : colors.white, 
                        border: isChecked ? `1.5px solid ${colors.gold}` : `1.5px solid ${colors.border}`, 
                        display: "flex", 
                        alignItems: "center", 
                        gap: "10px", 
                        padding: "12px 14px", 
                        borderRadius: "10px", 
                        cursor: "pointer",
                        transition: "all 0.2s"
                      }}
                    >
                      <input 
                        type="checkbox" 
                        checked={isChecked} 
                        onChange={(e) => {
                          const checked = e.target.checked;
                          setAddonQty(prev => ({
                            ...prev,
                            [addon.key]: checked ? (addon.unit && addon.unit.includes('/person') ? pax : 1) : 0
                          }));
                        }}
                        style={{ width: "18px", height: "18px", accentColor: colors.gold, cursor: "pointer" }}
                      />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: "13px", fontWeight: "800", color: colors.textDark, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                          {addon.icon} {addon.label}
                        </div>
                        <div style={{ fontSize: "11px", color: colors.textMuted }}>
                          AED {addon.price} {addon.unit}
                        </div>
                      </div>
                    </label>
                  );
                })}
              </div>
              
              {!isVip && (
                <div style={{ fontSize: "10px", color: colors.textMuted, fontStyle: "italic", paddingTop: "8px", textAlign: "center", borderTop: `1px dashed ${colors.border}`, marginTop: "10px" }}>
                  ❄️ AC seating upgrade active with VIP/Private tours only
                </div>
              )}
            </div>

          </div>

          {/* Checkout / Summary Box */}
          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
            
            {/* Main Summary Card */}
            <div style={{ background: colors.white, border: `1.5px solid ${colors.border}`, borderRadius: "16px", padding: "20px", display: "flex", flexDirection: "column", gap: "16px", position: "sticky", top: "20px" }}>
              <h3 style={{ fontSize: "15px", fontWeight: "900", color: colors.textDark, margin: "0 0 4px", borderBottom: `1.5px solid ${colors.border}`, paddingBottom: "8px" }}>
                Booking Summary
              </h3>

              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                <div style={{ fontSize: "10px", fontWeight: "800", color: colors.textMuted, textTransform: "uppercase", letterSpacing: "0.5px" }}>Selected Adventure</div>
                <div style={{ fontSize: "13px", fontWeight: "800", color: colors.textDark, lineHeight: 1.3 }}>{formData.categoryKey}</div>
                <div style={{ fontSize: "12px", color: colors.gold, fontWeight: "700" }}>
                  {selectedPkg ? (
                    activeCpn 
                      ? `${getCleanPackageName(selectedPkg.name)} (Promo Applied)` 
                      : getCleanPackageName(selectedPkg.name)
                  ) : "—"}
                </div>
              </div>

              {showCouponsSetting && (
                <div style={{ display: "flex", flexDirection: "column", gap: "6px", background: colors.sandBg, padding: "12px", borderRadius: "10px", border: `1px solid ${colors.border}` }}>
                  <label style={{ fontSize: "11px", fontWeight: "800", color: colors.textDark }}>Do you have a coupon code?</label>
                  <div style={{ display: "flex", gap: "6px" }}>
                    <input 
                      style={{ ...inpStyle, padding: "8px 12px", fontSize: "12px", flex: 1 }} 
                      placeholder="e.g. RoarNYOfferDxb" 
                      value={tempCouponCode}
                      onChange={(e) => setTempCouponCode(e.target.value.replace(/\s+/g, ""))}
                    />
                    <button 
                      type="button"
                      onClick={() => setCouponCode(tempCouponCode)}
                      style={{ background: colors.gold, color: colors.white, border: "none", borderRadius: "8px", padding: "0 14px", fontSize: "12px", fontWeight: "800", cursor: "pointer", fontFamily: "inherit" }}
                    >
                      Apply
                    </button>
                  </div>
                  {couponCode && (
                    <div style={{ fontSize: "11px", fontWeight: "800", color: cpnStatus.status === 'valid' ? colors.successText : '#ef4444', marginTop: '2px' }}>
                      {cpnStatus.message}
                    </div>
                  )}
                  {(!isCouponUnlocked && promoCoupon) && (
                    <button 
                      type="button" 
                      onClick={() => setIsUnlockModalOpen(true)}
                      style={{ background: "transparent", border: "none", padding: 0, color: colors.copper, fontSize: "10.5px", fontWeight: "800", cursor: "pointer", textTab: "left", textDecoration: "underline", display: "flex", alignItems: "center", gap: "3px", marginTop: "4px", outline: 'none' }}
                    >
                      <Sparkles size={11} /> Click here to unlock special promo offer!
                    </button>
                  )}
                </div>
              )}

              {/* Price Details */}
              <div style={{ display: "flex", flexDirection: "column", gap: "8px", fontSize: "13px", marginTop: "4px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ color: colors.textMuted }}>Base Rate:</span>
                  <span style={{ fontWeight: "700", color: colors.textDark, display: "flex", flexDirection: "column", alignItems: "flex-end" }}>
                    {activeCpn && (
                      <span style={{ textDecoration: "line-through", color: colors.textMuted, fontSize: "11px" }}>
                        AED {selectedPkg && (selectedPkg.category === 'Evening Desert Safari' || selectedPkg.id === 'morning_private') ? selectedPkg.peakRate : selectedPkg?.rate}
                      </span>
                    )}
                    <span>
                      AED {activeCpn ? activeCpn.customPrice : (selectedPkg ? ((selectedPkg.category === 'Evening Desert Safari' || selectedPkg.id === 'morning_private') ? selectedPkg.peakRate : selectedPkg.rate) : "—")} {selectedPkg?.type === 'flat' ? '/car' : '/person'}
                    </span>
                  </span>
                </div>

                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: colors.textMuted }}>Total Guests:</span>
                  <span style={{ fontWeight: "700", color: colors.textDark }}>{pax} Pax</span>
                </div>

                {selectedPkg && selectedPkg.type === 'flat' && (
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span style={{ color: colors.textMuted }}>Cars Required:</span>
                    <span style={{ fontWeight: "700", color: colors.textDark }}>{carsNeeded} Car{carsNeeded > 1 ? "s" : ""}</span>
                  </div>
                )}

                <div style={{ height: "1px", background: colors.border, margin: "4px 0" }} />

                <div style={{ display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: colors.textDark, fontWeight: "700" }}>Base Cost:</span>
                  <span style={{ fontWeight: "800", color: colors.textDark }}>AED {basePrice}</span>
                </div>

                {addonsTotal > 0 && (
                  <div style={{ display: "flex", justifyContent: "space-between" }}>
                    <span style={{ color: colors.textMuted }}>Add-ons Total:</span>
                    <span style={{ fontWeight: "700", color: colors.gold }}>+AED {addonsTotal}</span>
                  </div>
                )}

                {/* Selected Addons breakdown */}
                {displayAddons.filter(a => (addonQty[a.key] || 0) > 0).length > 0 && (
                  <div style={{ display: "flex", flexDirection: "column", gap: "4px", padding: "8px", background: colors.sandBg, borderRadius: "6px", fontSize: "11px", color: colors.textDark }}>
                    {displayAddons.filter(a => (addonQty[a.key] || 0) > 0).map(a => (
                      <div key={a.key} style={{ display: "flex", justifyContent: "space-between" }}>
                        <span>{a.label} (x{addonQty[a.key]})</span>
                        <span>+AED {addonQty[a.key] * a.price}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Total Box */}
              <div style={{ background: "rgba(197, 160, 89, 0.08)", border: `1.5px solid ${colors.gold}`, borderRadius: "10px", padding: "12px", display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: "6px" }}>
                <div>
                  <span style={{ fontSize: "10px", fontWeight: "800", color: colors.gold, textTransform: "uppercase" }}>Total Price</span>
                  <div style={{ fontSize: "9px", color: colors.textMuted }}>Pay Cash on Pickup</div>
                </div>
                <div style={{ fontSize: "22px", fontWeight: "900", color: colors.gold }}>
                  AED {totalPrice}
                </div>
              </div>

              <div style={{ background: colors.successBg, border: `1px solid rgba(21, 128, 61, 0.15)`, borderRadius: "8px", padding: "8px 10px", display: "flex", alignItems: "center", gap: "6px" }}>
                <span style={{ fontSize: "14px" }}>💳</span>
                <div style={{ fontSize: "10px", color: colors.successText, fontWeight: "700", lineHeight: 1.3 }}>
                  No deposit needed. Pay in cash directly to our driver on arrival.
                </div>
              </div>

              {/* Confirm submit */}
              <form onSubmit={handleSave} style={{ marginTop: "4px" }}>
                <button type="submit" disabled={submitting}
                  style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "center", gap: "6px", background: submitting ? colors.textMuted : colors.gold, color: colors.white, border: "none", borderRadius: "10px", padding: "13px 14px", fontSize: "14px", fontWeight: "900", cursor: submitting ? "not-allowed" : "pointer", boxShadow: submitting ? "none" : `0 4px 14px rgba(197, 160, 89, 0.35)`, transition: "all 0.2s", fontFamily: "inherit", outline: 'none' }}>
                  {submitting ? "Confirming..." : <><Check size={16} /> Confirm Booking — Pay on Arrival</>}
                </button>
              </form>
            </div>

          </div>

        </div>

      </div>

      {/* Floating Action Buttons */}
      <div className="floating-buttons-container" style={{ position: 'fixed', bottom: '24px', right: '24px', display: 'flex', flexDirection: 'column', gap: '10px', zIndex: 9999 }}>
        {/* Availability Check Button */}
        <a 
          href="https://wa.me/971589344077?text=Hi%20Roar%20Adventure%20Tourism%2C%20I%20want%20to%20check%20availability%20for%20a%20desert%20safari%20booking." 
          target="_blank" 
          rel="noopener noreferrer" 
          className="floating-btn alt"
          style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '8px', 
            background: colors.white, 
            color: colors.gold, 
            padding: '12px 18px', 
            borderRadius: '50px', 
            textDecoration: 'none', 
            fontWeight: '800', 
            fontSize: '13px', 
            border: `1.5px solid ${colors.gold}`,
            boxShadow: '0 4px 12px rgba(197, 160, 89, 0.15)',
            transition: 'all 0.2s'
          }}
        >
          📅 Check Availability
        </a>

        {/* WhatsApp Chat Button */}
        <a 
          href="https://wa.me/971556054570?text=Hi%20Roar%20Adventure%20Tourism%2C%20I%20have%20a%20question%20about%20your%20desert%20safari%20packages." 
          target="_blank" 
          rel="noopener noreferrer" 
          className="floating-btn"
          style={{ 
            display: 'flex', 
            alignItems: 'center', 
            gap: '8px', 
            background: colors.gold, 
            color: colors.white, 
            padding: '12px 18px', 
            borderRadius: '50px', 
            textDecoration: 'none', 
            fontWeight: '800', 
            fontSize: '13px', 
            boxShadow: '0 4px 12px rgba(197, 160, 89, 0.3)',
            transition: 'all 0.2s'
          }}
        >
          💬 Live Chat
        </a>
      </div>

      {/* Coupon Unlock Modal */}
      {isUnlockModalOpen && (
        <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(84, 61, 43, 0.4)', backdropFilter: 'blur(4px)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 99999, padding: '16px' }}>
          <div style={{ maxWidth: '400px', width: '100%', padding: '24px', borderRadius: '16px', background: colors.white, border: `1.5px solid ${colors.border}`, boxShadow: '0 20px 40px rgba(0,0,0,0.05)', position: 'relative' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
              <h3 style={{ fontSize: '18px', fontWeight: '900', color: colors.textDark, margin: 0 }}>Unlock Coupon Code</h3>
              <button type="button" onClick={() => setIsUnlockModalOpen(false)} style={{ border: 'none', background: 'none', cursor: 'pointer', outline: 'none', color: colors.textMuted, fontSize: '24px', padding: 0 }}>&times;</button>
            </div>
            
            <form onSubmit={handleUnlockCoupon}>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '14px', marginTop: '12px' }}>
                <p style={{ fontSize: '13px', color: colors.textMuted, margin: 0, lineHeight: 1.4 }}>
                  Enter your email address below to unlock the promo code and automatically apply the discount rate to your booking!
                </p>

                <div className="form-group">
                  <label style={{ fontSize: '11px', fontWeight: '800', color: colors.textMuted, marginBottom: '4px', display: 'block' }}>Email Address *</label>
                  <input 
                    type="email" 
                    className="form-control" 
                    style={inpStyle}
                    placeholder="e.g. john@example.com"
                    value={leadEmail}
                    onChange={(e) => setLeadEmail(e.target.value)}
                    required
                  />
                </div>

                <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '10px' }}>
                  <button type="button" onClick={() => setIsUnlockModalOpen(false)} style={{ background: 'transparent', border: `1.5px solid ${colors.border}`, borderRadius: '10px', padding: '10px 18px', cursor: 'pointer', fontWeight: '750', color: colors.textMuted, fontSize: '13px', fontFamily: 'inherit', outline: 'none' }}>Cancel</button>
                  <button type="submit" style={{ background: colors.gold, color: colors.white, border: 'none', borderRadius: '10px', padding: '10px 18px', cursor: 'pointer', fontWeight: '900', fontSize: '13px', fontFamily: 'inherit', outline: 'none', boxShadow: `0 4px 12px rgba(197,160,89,0.25)` }}>Unlock & Apply</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      <style>{`
        @keyframes fIn { from { opacity:0; transform:scale(1.02); } to { opacity:1; transform:scale(1); } }
        input:focus, select:focus { border-color: ${colors.gold} !important; box-shadow: 0 0 0 3px rgba(197, 160, 89, 0.15) !important; }
        
        .booking-layout-grid {
          display: grid;
          grid-template-columns: 1.5fr 1fr;
          gap: 20px;
          align-items: start;
        }

        .addons-grid-layout {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
          align-content: start;
          overflow-y: auto;
        }

        .floating-btn:hover {
          transform: translateY(-2px);
        }
        .floating-btn.alt:hover {
          background-color: ${colors.sandBg} !important;
          transform: translateY(-2px);
        }

        @media (max-width: 900px) {
          .booking-layout-grid {
            grid-template-columns: 1fr !important;
          }
        }

        @media (max-width: 600px) {
          .addons-grid-layout {
            grid-template-columns: repeat(2, 1fr) !important;
            gap: 10px !important;
          }
          .floating-buttons-container {
            bottom: 16px !important;
            right: 16px !important;
            left: 16px !important;
            flex-direction: row !important;
            gap: 10px !important;
            justify-content: space-between !important;
          }
          .floating-btn {
            flex: 1;
            justify-content: center;
            padding: 10px 12px !important;
            fontSize: 12px !important;
          }
        }
      `}</style>
    </div>
  );
}