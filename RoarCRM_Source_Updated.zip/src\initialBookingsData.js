export const initialBookings = [];
